"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const dotenv_1 = __importDefault(require("dotenv"));
const db_1 = __importDefault(require("./db"));
const path_1 = __importDefault(require("path"));
const sanitize_html_1 = __importDefault(require("sanitize-html"));
const cookie_parser_1 = __importDefault(require("cookie-parser"));
// Carrega as variáveis de ambiente definidas no arquivo .env
dotenv_1.default.config();
// Inicializa a aplicação Express
const app = (0, express_1.default)();
// Define a porta utilizada pelo servidor
const PORT = process.env.PORT || 3000;
// Middleware para permitir o envio de dados em formato JSON no corpo das requisições
app.use(express_1.default.json());
// Middleware para habilitar requisições de diferentes origens (CORS)
app.use((0, cors_1.default)());
// Middleware que interpreta cookies enviados nas requisições HTTP.
// Isso possibilita o acesso aos cookies através de `req.cookies`.
app.use((0, cookie_parser_1.default)());
// Middleware para servir arquivos estáticos a partir do diretório "public"
app.use(express_1.default.static("public"));
// Inicializa o servidor na porta definida
app.listen(PORT, function () {
    console.log(`Servidor rodando em http://localhost:${PORT}`);
});
// ****** ROTAS PARA PÁGINAS HTML ESTÁTICAS ******
app.get("/stored-xss", (_, res) => {
    res.sendFile(path_1.default.join(__dirname, "..", "public", "stored-xss.html"));
});
app.get("/dom-xss", (_, res) => {
    res.sendFile(path_1.default.join(__dirname, "..", "public", "dom-based-xss.html"));
});
app.get("/dom-xss-sanitize", (_, res) => {
    res.sendFile(path_1.default.join(__dirname, "..", "public", "dom-based-xss-sanitize.html"));
});
app.get("/exercicio1-vulneravel", (_, res) => {
    res.sendFile(path_1.default.join(__dirname, "..", "public", "exercicio1-vulneravel.html"));
});
app.get("/exercicio1-resposta", (_, res) => {
    res.sendFile(path_1.default.join(__dirname, "..", "public", "exercicio1-resposta.html"));
});
app.get("/exercicio2-vulneravel", (_, res) => {
    res.sendFile(path_1.default.join(__dirname, "..", "public", "exercicio2-vulneravel.html"));
});
app.get("/exercicio2-resposta", (_, res) => {
    res.sendFile(path_1.default.join(__dirname, "..", "public", "exercicio2-resposta.html"));
});
app.get("/exercicio3-resposta", (_, res) => {
    res.sendFile(path_1.default.join(__dirname, "..", "public", "exercicio3-resposta.html"));
});
app.get("/exercicio4-vulneravel", (_, res) => {
    res.sendFile(path_1.default.join(__dirname, "..", "public", "exercicio4-vulneravel.html"));
});
// ****** STORED XSS ******
// Rota para inserir comentário vulnerável (sem sanitização)
app.post("/comment", (req, res) => {
    const comment = req.body.comment;
    db_1.default.query("INSERT INTO comments (text) VALUES ($1)", [comment]);
    res.json({ message: "Comentário adicionado!" });
});
// Rota para exibir comentários armazenados (potencialmente maliciosos)
app.get("/comments", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const result = yield db_1.default.query("SELECT text FROM comments");
    res.header("Content-Type", "text/html");
    res.send(result.rows.map((row) => `<div>${row.text}</div>`).join(""));
}));
// Rota para inserir comentário com sanitização
app.post("/comment-sanitize", (req, res) => {
    const comment = req.body.comment;
    // Remove todas as tags HTML e atributos
    const sanitizedComment = (0, sanitize_html_1.default)(comment, {
        allowedTags: [],
        allowedAttributes: {},
    });
    db_1.default.query("INSERT INTO comments_sanitize (text) VALUES ($1)", [sanitizedComment]);
    res.json({ message: "Comentário adicionado com segurança!" });
});
// Rota para exibir comentários sanitizados
app.get("/comments-sanitize", (req, res) => __awaiter(void 0, void 0, void 0, function* () {
    const result = yield db_1.default.query("SELECT text FROM comments_sanitize");
    res.header("Content-Type", "text/html");
    res.send(result.rows.map((row) => `<div>${row.text}</div>`).join(""));
}));
// ****** REFLECTED XSS ******
// Rota vulnerável que reflete diretamente o valor da query string na resposta
app.get("/search", (req, res) => {
    const input = req.query.q;
    res.send(`
    <html>
      <body>
        <h3>Resultados da busca:</h3>
        <p>Você pesquisou por: ${input}</p>
      </body>
    </html>
  `);
});
// Rota com sanitização contra Reflected XSS
app.get("/search-sanitize", (req, res) => {
    const input = req.query.q;
    const sanitizedInput = (0, sanitize_html_1.default)(input, {
        allowedTags: [],
        allowedAttributes: {},
    });
    res.send(`
    <html>
      <body>
        <h3>Resultados da busca:</h3>
        <p>Você pesquisou por: ${sanitizedInput}</p>
      </body>
    </html>
  `);
});

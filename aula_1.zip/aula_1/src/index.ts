import express, {Request, Response} from "express";
import cors from "cors";
import dotenv from "dotenv";
import db from "./db";

dotenv.config();

const app = express();

const PORT = process.env.PORT || 3000; 

app.use(express.json());

app.use(cors());

app.listen(PORT, function () {
     console.log(`Servidor rodando em http://localhost:${PORT}`);
});
app.post("/login-inseguro", async function (req: Request, res: Response) {
      const { username, password } = req.body;
    
      // Código vulnerável a SQL Injection
      const query = `SELECT * FROM users WHERE username = '${username}' AND password = '${password}'`;
      
      try {
        const result = await db.query(query);
        if ( result.rowCount !== 0) {
          res.json({message:"Login bem-sucedido"});
        } else {
          res.status(401).json({message:"Usuário ou senha inválidos"});
        }
      } catch (e:any) {
        res.status(500).json({message:"Erro no servidor"});
      }
});



app.post("/login-seguro", async function (req: Request, res: Response) {
      const { username, password } = req.body;
    
      // Consultas parâmetrizadas
      const query = `SELECT * FROM users WHERE username = $1 AND password = $2`;
      try {
            const result = await db.query(query, [username, password]);
            if ( result.rowCount !== 0) {
              res.json({message:"Login bem-sucedido"});
            } else {
              res.status(401).json({message:"Usuário ou senha inválidos"});
            }
          } catch (e:any) {
            res.status(500).json({message:"Erro no servidor"});
          }
    });